"""
Optional LLM helpers for advisor/predictor narrative output.

This module is safe-by-default:
- Disabled unless ENABLE_AGENT=true
- Falls back to None on any API error/timeout
- Uses small in-memory cache to reduce repeated API calls
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from collections import OrderedDict
from typing import Any

import requests


OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
NVIDIA_CHAT_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
DEFAULT_OPENAI_MODEL = "gpt-4.1-mini"
DEFAULT_NVIDIA_MODEL = "moonshotai/kimi-k2.5"
DEFAULT_CONNECT_TIMEOUT = 3
DEFAULT_READ_TIMEOUT = 8
DEFAULT_HARD_TIMEOUT = 12
CACHE_MAX = 256

_CACHE: "OrderedDict[str, str]" = OrderedDict()
_LAST_ERROR: str | None = None


def _set_last_error(msg: str | None) -> None:
    global _LAST_ERROR
    _LAST_ERROR = msg


def _env_true(name: str, default: str = "false") -> bool:
    val = os.getenv(name, default).strip().lower()
    return val in {"1", "true", "yes", "on"}


def agent_enabled() -> bool:
    return _env_true("ENABLE_AGENT", "false")


def agent_provider() -> str:
    provider = os.getenv("AGENT_PROVIDER", "openai").strip().lower()
    if provider in {"nvidia", "openai"}:
        return provider
    return "openai"


def _cache_get(key: str) -> str | None:
    if key not in _CACHE:
        return None
    _CACHE.move_to_end(key)
    return _CACHE[key]


def _cache_set(key: str, value: str) -> None:
    _CACHE[key] = value
    _CACHE.move_to_end(key)
    if len(_CACHE) > CACHE_MAX:
        _CACHE.popitem(last=False)


def _make_cache_key(prefix: str, payload: dict[str, Any], model: str) -> str:
    body = json.dumps({"prefix": prefix, "model": model, "payload": payload}, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict):
                txt = item.get("text")
                if isinstance(txt, str):
                    parts.append(txt)
        return "\n".join(parts).strip()
    return ""


def _provider_config() -> tuple[str, str, str, str]:
    provider = agent_provider()
    if provider == "nvidia":
        api_key = os.getenv("NVIDIA_API_KEY") or os.getenv("OPENAI_API_KEY", "")
        model = os.getenv("NVIDIA_MODEL", DEFAULT_NVIDIA_MODEL).strip() or DEFAULT_NVIDIA_MODEL
        return provider, NVIDIA_CHAT_URL, api_key, model

    api_key = os.getenv("OPENAI_API_KEY", "")
    model = os.getenv("OPENAI_MODEL", DEFAULT_OPENAI_MODEL).strip() or DEFAULT_OPENAI_MODEL
    return provider, OPENAI_CHAT_URL, api_key, model


def _env_int(name: str, default: int, min_value: int = 32) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        val = int(raw)
    except Exception:
        val = default
    return max(min_value, val)


def _fallback_models(provider: str, primary_model: str) -> list[str]:
    raw = os.getenv("AGENT_FALLBACK_MODELS", "").strip()
    if raw:
        return [m.strip() for m in raw.split(",") if m.strip() and m.strip() != primary_model]

    if provider == "nvidia":
        if primary_model == "deepseek-ai/deepseek-v3.2":
            return ["moonshotai/kimi-k2.5", "meta/llama-3.1-8b-instruct"]
        if primary_model == "moonshotai/kimi-k2.5":
            return ["meta/llama-3.1-8b-instruct"]
    return []


def _chat_completion(system_prompt: str, user_prompt: str, max_tokens: int = 260) -> str | None:
    if not agent_enabled():
        return None

    _set_last_error(None)
    provider, endpoint, api_key, model = _provider_config()
    if not api_key:
        _set_last_error("Missing API key for selected provider")
        return None

    timeout_override = os.getenv("AGENT_TIMEOUT_SECONDS")
    if timeout_override and timeout_override.strip():
        total_timeout = float(timeout_override)
        timeout = (max(1.0, total_timeout / 3), max(1.0, total_timeout))
    else:
        connect_timeout = float(os.getenv("AGENT_CONNECT_TIMEOUT_SECONDS", str(DEFAULT_CONNECT_TIMEOUT)))
        read_timeout = float(os.getenv("AGENT_READ_TIMEOUT_SECONDS", str(DEFAULT_READ_TIMEOUT)))
        timeout = (max(1.0, connect_timeout), max(1.0, read_timeout))

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Connection": "close",
    }
    body_template = {
        "temperature": 0.2,
        "max_tokens": max_tokens,
        "stream": False,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }
    hard_timeout = float(os.getenv("AGENT_HARD_TIMEOUT_SECONDS", str(DEFAULT_HARD_TIMEOUT)))
    retry_count = max(0, int(os.getenv("AGENT_MAX_RETRIES", "1")))
    retry_backoff = max(0.0, float(os.getenv("AGENT_RETRY_BACKOFF_SECONDS", "1.2")))

    models_to_try = [model] + _fallback_models(provider, model)
    tried = []
    last_err = "No response from provider"

    for model_name in models_to_try:
        tried.append(model_name)
        for attempt in range(retry_count + 1):
            body = dict(body_template)
            body["model"] = model_name
            if model_name == "moonshotai/kimi-k2.5" and _env_true("AGENT_KIMI_INSTANT_MODE", "true"):
                body["thinking"] = {"type": "disabled"}

            resp_box: dict[str, requests.Response] = {}
            err_box: dict[str, Exception] = {}

            def _do_post() -> None:
                try:
                    resp_box["resp"] = requests.post(endpoint, headers=headers, json=body, timeout=timeout)
                except Exception as exc:
                    err_box["err"] = exc

            try:
                t = threading.Thread(target=_do_post, daemon=True)
                t.start()
                if hard_timeout <= 0:
                    t.join()
                else:
                    t.join(max(1.0, hard_timeout))
                if hard_timeout > 0 and t.is_alive():
                    last_err = f"Hard timeout after {hard_timeout:.1f}s"
                    if attempt < retry_count:
                        time.sleep(retry_backoff * (attempt + 1))
                        continue
                    break
                if "err" in err_box:
                    raise err_box["err"]

                resp = resp_box["resp"]
                if resp.status_code == 202:
                    last_err = "Provider returned HTTP 202 (async/in-progress response)"
                    break
                resp.raise_for_status()
                payload = resp.json()
                choices = payload.get("choices") or []
                if not choices:
                    short = str(payload)[:220]
                    last_err = f"No choices in response payload: {short}"
                    break
                msg = choices[0].get("message", {})
                refusal = msg.get("refusal")
                if isinstance(refusal, str) and refusal.strip():
                    _set_last_error(f"Model refusal: {refusal[:180]}")
                    return refusal.strip()
                text = _extract_text(msg.get("content"))
                if text:
                    _set_last_error(None)
                    return text
                last_err = f"Empty model content. finish_reason={choices[0].get('finish_reason')}"
                break
            except requests.Timeout:
                last_err = "Timeout while waiting for model response"
                if attempt < retry_count:
                    time.sleep(retry_backoff * (attempt + 1))
                    continue
                break
            except requests.HTTPError as e:
                status = e.response.status_code if e.response is not None else None
                body_preview = (e.response.text or "")[:220] if e.response is not None else ""
                last_err = f"HTTP {status}: {body_preview}" if status is not None else f"HTTP error: {e}"
                retryable = status in {408, 429, 500, 502, 503, 504}
                if retryable and attempt < retry_count:
                    time.sleep(retry_backoff * (attempt + 1))
                    continue
                break
            except Exception as e:
                last_err = f"Request error: {e}"
                if attempt < retry_count:
                    time.sleep(retry_backoff * (attempt + 1))
                    continue
                break

    _set_last_error(f"{last_err} (tried models: {', '.join(tried)})")
    return None


def build_advisor_agent_plan(
    city: str,
    row: dict[str, Any],
    shap_drivers: list[dict[str, Any]],
    recommendations: list[dict[str, Any]],
    strengths: list[str],
    weaknesses: list[str],
) -> str | None:
    if not agent_enabled():
        return None

    payload = {
        "city": city,
        "superhost_probability": row.get("superhost_probability"),
        "response_rate": row.get("host_response_rate_clean"),
        "amenity_count": row.get("amenity_count"),
        "top_drivers": shap_drivers[:6],
        "recommendations": recommendations[:5],
        "strengths": strengths[:5],
        "weaknesses": weaknesses[:5],
    }
    _provider, _endpoint, _api_key, model = _provider_config()
    key = _make_cache_key("advisor", payload, model)
    cached = _cache_get(key)
    if cached:
        return cached

    system_prompt = (
        "You are an Airbnb host operations strategist. "
        "Write concise, practical recommendations in Markdown."
    )
    user_prompt = (
        "Create a compact action plan in Markdown with:\n"
        "1) A one-line diagnosis\n"
        "2) A 'Next 7 days' checklist (3 bullets)\n"
        "3) A 'Next 30 days' checklist (3 bullets)\n"
        "4) Budget guidance (short)\n\n"
        f"Input data:\n{json.dumps(payload, ensure_ascii=False)}"
    )
    text = _chat_completion(
        system_prompt,
        user_prompt,
        max_tokens=_env_int("AGENT_ADVISOR_PLAN_MAX_TOKENS", 280),
    )
    if text:
        _cache_set(key, text)
    return text


def build_predictor_whatif_plan(
    city: str,
    budget: float,
    base_price: float,
    scenarios: list[dict[str, Any]],
) -> str | None:
    if not agent_enabled():
        return None

    payload = {
        "city": city,
        "budget": budget,
        "base_price": base_price,
        "scenarios": scenarios[:3],
    }
    _provider, _endpoint, _api_key, model = _provider_config()
    key = _make_cache_key("predictor_whatif", payload, model)
    cached = _cache_get(key)
    if cached:
        return cached

    system_prompt = (
        "You are a short-term rental investment analyst. "
        "Return concise decision-oriented Markdown."
    )
    user_prompt = (
        "Given the ranked what-if scenarios, provide:\n"
        "1) Best option and why (1-2 lines)\n"
        "2) 7-day implementation checklist (3 bullets)\n"
        "3) One downside risk to monitor\n\n"
        f"Input data:\n{json.dumps(payload, ensure_ascii=False)}"
    )
    text = _chat_completion(
        system_prompt,
        user_prompt,
        max_tokens=_env_int("AGENT_PREDICTOR_WHATIF_MAX_TOKENS", 240),
    )
    if text:
        _cache_set(key, text)
    return text


def agent_status_text() -> str:
    if not agent_enabled():
        return "Agent disabled (`ENABLE_AGENT` is false)"
    provider, endpoint, api_key, model = _provider_config()
    if not api_key:
        key_name = "NVIDIA_API_KEY (or OPENAI_API_KEY fallback)" if provider == "nvidia" else "OPENAI_API_KEY"
        return f"Agent enabled but `{key_name}` is missing"
    if _LAST_ERROR:
        return f"Agent enabled via `{provider}` model `{model}` at `{endpoint}`. Last error: {_LAST_ERROR}"
    return f"Agent enabled via `{provider}` model `{model}` at `{endpoint}`"
