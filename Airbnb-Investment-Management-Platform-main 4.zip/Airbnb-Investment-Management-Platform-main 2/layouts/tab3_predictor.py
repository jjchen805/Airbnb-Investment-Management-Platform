"""
Tab 3 — Investor Price Predictor Layout
========================================
Output panel driven by local SHAP values + amenity gap analysis.
"""
from dash import html, dcc
import dash_bootstrap_components as dbc

NEIGHBOURHOODS = [
    "Bernal Heights", "Castro/Upper Market", "Chinatown",
    "Downtown/Civic Center", "Excelsior", "Financial District",
    "Haight Ashbury", "Inner Richmond", "Inner Sunset", "Marina",
    "Mission", "Nob Hill", "Noe Valley", "North Beach", "Other",
    "Outer Richmond", "Outer Sunset", "Pacific Heights",
    "Russian Hill", "South of Market", "Western Addition",
]

PROPERTY_TYPES = [
    "Entire condo", "Entire guest suite", "Entire home",
    "Entire rental unit", "Entire serviced apartment",
    "Private room in condo", "Private room in home",
    "Private room in rental unit", "Room in boutique hotel",
    "Room in hotel", "Other",
]

AMENITIES = [
    ("has_wifi",            "WiFi"),
    ("has_kitchen",         "Kitchen"),
    ("has_washer",          "Washer"),
    ("has_dryer",           "Dryer"),
    ("has_parking",         "Parking"),
    ("has_air_conditioning","AC"),
    ("has_heating",         "Heating"),
    ("has_tv",              "TV"),
    ("has_self_check-in",   "Self check-in"),
    ("has_coffee",          "Coffee maker"),
    ("has_hair_dryer",      "Hair dryer"),
    ("has_iron",            "Iron"),
    ("has_gym",             "Gym"),
    ("has_pool",            "Pool"),
    ("has_hot_tub",         "Hot tub"),
    ("has_elevator",        "Elevator"),
]

DEFAULT_ON = {"has_wifi", "has_kitchen", "has_heating", "has_tv", "has_hair_dryer"}

# Apple system colors
C = {
    "blue":   "#0071E3",
    "green":  "#34C759",
    "orange": "#FF9F0A",
    "red":    "#FF3B30",
    "gray1":  "#1D1D1F",
    "gray2":  "#3A3A3C",
    "gray3":  "#6E6E73",
    "gray4":  "#AEAEB2",
    "gray5":  "#C7C7CC",
    "gray6":  "#F2F2F7",
}

def predictor_layout(meta: dict):
    neighbourhoods = sorted([r["neighbourhood_top"] for r in meta["neighbourhoods"]])
    property_types = sorted([r["property_type_simple"] for r in meta["property_types"]])
    return html.Div([
        html.H4("Airbnb Price Predictor", 
                style={"fontSize": "22px", "fontWeight": "700",
                           "color": C["gray1"], "marginBottom": "4px"}),
        html.P(
            "Enter your planned listing details and get an ML-based nightly price estimate "
            "benchmarked against the market.",
            style={"fontSize": "14px", "color": C["gray3"], "marginBottom": "24px"},
        ),

        dbc.Row([
            # ── LEFT: Input form ─────────────────────────────────────────────
            dbc.Col([

                dbc.Card([
                    dbc.CardHeader("LOCATION"),
                    dbc.CardBody([
                        dbc.Label("Neighborhood"),
                        dcc.Dropdown(
                            id="inv-neighbourhood",
                            options=[{"label": n, "value": n} for n in neighbourhoods],
                            value="Mission", clearable=False,
                        ),
                    ]),
                ], className="mb-3"),

                dbc.Card([
                    dbc.CardHeader("PROPERTY SETUP"),
                    dbc.CardBody([
                        dbc.Row([
                            dbc.Col([
                                dbc.Label("Property Type"),
                                dcc.Dropdown(
                                    id="inv-property-type",
                                    options=[{"label": p, "value": p} for p in property_types],
                                    value="Entire rental unit", clearable=False,
                                ),
                            ], width=12, className="mb-3"),
                        ]),
                        dbc.Row([
                            dbc.Col([dbc.Label("Accommodates"), dbc.Input(id="inv-accommodates", type="number", value=4, min=1, max=16)], width=4),
                            dbc.Col([dbc.Label("Bedrooms"),     dbc.Input(id="inv-bedrooms",     type="number", value=1, min=0, max=10)], width=4),
                            dbc.Col([dbc.Label("Bathrooms"),    dbc.Input(id="inv-bathrooms",    type="number", value=1, min=0.5, max=8, step=0.5)], width=4),
                        ], className="mb-2"),
                        dbc.Row([
                            dbc.Col([dbc.Label("Beds"),           dbc.Input(id="inv-beds",           type="number", value=1, min=1, max=16)], width=4),
                            dbc.Col([dbc.Label("Min nights"),     dbc.Input(id="inv-min-nights",     type="number", value=2, min=1, max=365)], width=4),
                            dbc.Col([dbc.Label("Avail. / yr"),    dbc.Input(id="inv-availability-365", type="number", value=200, min=0, max=365)], width=4),
                        ]),
                    ]),
                ], className="mb-3"),

                dbc.Card([
                    dbc.CardHeader("HOST SETUP"),
                    dbc.CardBody([
                        dbc.Row([
                            dbc.Col([
                                dbc.Label("Instant bookable?"),
                                dbc.RadioItems(
                                    id="inv-instant-bookable",
                                    options=[{"label": "Yes", "value": 1}, {"label": "No", "value": 0}],
                                    value=0, inline=True,
                                ),
                            ], width=6),
                            dbc.Col([
                                dbc.Label("Superhost?"),
                                dbc.RadioItems(
                                    id="inv-superhost",
                                    options=[{"label": "Yes", "value": 1.0}, {"label": "No", "value": 0.0}],
                                    value=0.0, inline=True,
                                ),
                            ], width=6),
                        ], className="mb-2"),
                        dbc.Row([
                            dbc.Col([
                                dbc.Label("Total host listings"),
                                dbc.Input(id="inv-host-listings", type="number", value=1, min=1, max=100),
                            ], width=6),
                        ]),
                    ]),
                ], className="mb-3"),

                dbc.Card([
                    dbc.CardHeader("AMENITIES"),
                    dbc.CardBody([
                        dbc.Row([
                            dbc.Col(
                                dbc.Checklist(
                                    options=[{"label": label, "value": 1}],
                                    value=[1] if col in DEFAULT_ON else [],
                                    id=f"inv-{col}",
                                    switch=True,
                                ),
                                width=6, className="mb-1"
                            )
                            for col, label in AMENITIES
                        ]),
                        html.Hr(className="my-2"),
                        dbc.Row([
                            dbc.Col([
                                dbc.Label("Total amenity count (approx.)"),
                                dbc.Input(id="inv-amenity-count", type="number", value=25, min=0, max=100),
                            ], width=6),
                        ]),
                    ]),
                ], className="mb-3"),

                dbc.Button(
                    "🔮  Predict Nightly Price",
                    id="inv-predict-btn",
                    size="lg",
                    className="w-100 mb-4",
                    style={"background": "#0071E3", "border": "none", "borderRadius": "14px", "fontSize": "15px", "fontWeight": "600"},
                    n_clicks=0,
                ),

            ], md=5),

            # ── RIGHT: Output panel ──────────────────────────────────────────
            dbc.Col([
                html.Div(id="inv-output-panel", children=[_empty_output_panel()])
            ], md=7),
        ]),
        dcc.Store(id="inv-whatif-context"),
        dcc.Store(id="inv-agent-context"),
    ], style={"padding": "24px 32px"})


def _empty_output_panel():
    return dbc.Card([
        dbc.CardBody([
            html.Div([
                html.Div("🏡", style={"fontSize": "48px", "textAlign": "center"}),
                html.P(
                    "Fill in your listing details and click Predict Nightly Price.",
                    className="text-muted text-center mt-3"
                ),
            ], className="py-5")
        ])
    ], )


# ── Output panel ──────────────────────────────────────────────────────────────

def build_output_panel(result: dict, whatif_plan: dict | None = None):
    """
    Build the full result panel from the predict_price() result dict.
    """
    predicted_price = result["predicted_price"]
    nbhd_median     = result["nbhd_median"]
    prop_median     = result["prop_median"]
    pct_vs_nbhd     = result["pct_vs_nbhd"]
    neighbourhood   = result["neighbourhood"]
    property_type   = result["property_type"]
    drivers         = result["drivers"]
    amenity_gaps    = result["amenity_gaps"]

    pct_vs_prop = ((predicted_price - prop_median) / prop_median) * 100

    return html.Div([
        _predicted_price_card(predicted_price),
        _market_comparison_card(predicted_price, neighbourhood, nbhd_median, pct_vs_nbhd, property_type, prop_median, pct_vs_prop),
        _shap_drivers_card(drivers, predicted_price),
        _amenity_tips_card(amenity_gaps, neighbourhood, pct_vs_nbhd, result.get("city", "sf")),
        _whatif_agent_card(whatif_plan or {}),
    ])


def _predicted_price_card(predicted_price):
    low  = predicted_price * 0.88
    high = predicted_price * 1.12
    return dbc.Card([
        dbc.CardBody([
            html.P("Predicted nightly price", className="text-muted mb-1 small"),
            html.H1(
                f"${predicted_price:,.0f}",
                className="display-4 fw-bold mb-0", 
                style={"color": "#0071E3", "letterSpacing": "-2px"},
            ),
            html.P(
                f"Estimated range: ${low:,.0f} – ${high:,.0f}",
                className="text-muted small mt-1"
            ),
        ], className="text-center py-4")
    ], className="mb-3")


def _market_comparison_card(predicted_price, neighbourhood, nbhd_median, pct_vs_nbhd, property_type, prop_median, pct_vs_prop):
    def badge(pct):
        color = "success" if pct >= 0 else "danger"
        sign  = "+" if pct >= 0 else ""
        return dbc.Badge(f"{sign}{pct:.1f}% vs avg", color=color, className="ms-2 fs-6")

    return dbc.Card([
        dbc.CardHeader("MARKET COMPARISON"),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.P("Neighborhood median", className="text-muted small mb-0"),
                    html.H5([f"${nbhd_median:,.0f}", badge(pct_vs_nbhd)], className="mb-0"),
                    html.Small(neighbourhood, className="text-muted"),
                ], width=6),
                dbc.Col([
                    html.P("Property type median", className="text-muted small mb-0"),
                    html.H5([f"${prop_median:,.0f}", badge(pct_vs_prop)], className="mb-0"),
                    html.Small(property_type, className="text-muted"),
                ], width=6),
            ]),
        ])
    ], className="mb-3")


def _shap_drivers_card(drivers: list, predicted_price: float):
    """
    Waterfall-style SHAP driver chart.
    Each bar shows direction (green=positive, red=negative) and dollar impact.
    """
    max_abs = max(abs(d["dollar_impact"]) for d in drivers) if drivers else 1

    rows = []
    for d in drivers:
        pct_width  = int(min(abs(d["dollar_impact"]) / max_abs * 100, 100))
        color      = "#198754" if d["direction"] == "up" else "#dc3545"
        sign       = "+" if d["direction"] == "up" else "-"
        dollar_str = f"{sign}${abs(d['dollar_impact']):,.0f}"

        rows.append(
            dbc.Row([
                dbc.Col(
                    html.Span(d["label"], className="text-muted", style={"fontSize": "13px"}),
                    width=5
                ),
                dbc.Col(
                    html.Div(
                        html.Div(style={
                            "width": f"{pct_width}%",
                            "height": "8px",
                            "background": color,
                            "borderRadius": "4px",
                            "transition": "width 0.4s ease",
                        }),
                        style={"background": "#F2F2F7", "borderRadius": "4px"}
                    ),
                    width=5
                ),
                dbc.Col(
                    html.Span(dollar_str, style={"fontSize": "12px", "color": color, "fontWeight": "600"}),
                    width=2
                ),
            ], align="center", className="mb-2")
        )

    return dbc.Card([
        dbc.CardHeader([
            "KEY PRICE DRIVERS",
            html.Span(
                " — how each factor pushed your price up or down from the SF baseline",
                className="text-muted fw-normal small"
            ),
        ]),
        dbc.CardBody([
            html.P(
                f"SF baseline (avg prediction): ${drivers[0]['dollar_impact'] and '—' or '—'}",
                className="text-muted small mb-3"
            ) if not drivers else None,
            *rows,
            html.Hr(className="my-2"),
            html.P(
                "Dollar values show each feature's approximate contribution to your predicted price, "
                "computed from CatBoost TreeSHAP values.",
                className="text-muted small mb-0"
            ),
        ])
    ], className="mb-3")


def _amenity_tips_card(amenity_gaps: list, neighbourhood: str, pct_vs_nbhd: float, city: str = "sf"):
    """
    Amenity-aware investor tips.
    Each unchecked amenity with meaningful market lift gets a targeted tip,
    grounded in actual SF data for this neighbourhood.
    """
    tip_items = []

    # Amenity-specific tips from data
    for gap in amenity_gaps:
        label       = gap["label"]
        market_lift = gap["market_lift"]
        tip_items.append(
            dbc.ListGroupItem([
                html.Div([
                    html.Span(f"Add {label}", className="fw-semibold"),
                    dbc.Badge(
                        f"+${market_lift:,.0f} median lift in {neighbourhood}",
                        color="success", className="ms-2 small"
                    ),
                ]),
                html.Small(
                    f"Listings in {neighbourhood} with {label.lower()} have a "
                    f"${market_lift:,.0f} higher median nightly price than those without.",
                    className="text-muted"
                ),
            ], className="border-0 px-0 py-2")
        )

    # Positioning tip (based on SHAP/market output, not hardcoded)
    if pct_vs_nbhd < -15:
        positioning_tip = (
            "Your predicted price is below the neighborhood average. "
            "Adding premium amenities (gym, pool, hot tub) could close this gap significantly."
        )
    elif pct_vs_nbhd > 20:
        positioning_tip = (
            "Your price is well above the neighborhood average. "
            "Prioritize earning strong early reviews to sustain occupancy at this price point."
        )
    else:
        positioning_tip = (
            "Your pricing is in line with the market. "
            "Gaining Superhost status early tends to improve both occupancy and price ceiling."
        )

    tip_items.append(
        dbc.ListGroupItem([
            html.Span("Market positioning", className="fw-semibold"),
            html.Br(),
            html.Small(positioning_tip, className="text-muted"),
        ], className="border-0 px-0 py-2")
    )

    # Generic but always-useful tip
    tip_items.append(
        dbc.ListGroupItem([
            html.Span("Enable self check-in & instant book", className="fw-semibold"),
            html.Br(),
            html.Small(
                f"These two settings increase booking conversion and are associated with "
                f"a higher median price in {city.upper()}.",
                className="text-muted"
            ),
        ], className="border-0 px-0 py-2")
    )

    return dbc.Card([
        dbc.CardHeader("INVESTOR TIPS"),
        dbc.CardBody([
            html.P(
                f"Based on your listing configuration and {city.upper()} market data:",
                className="text-muted small mb-2"
            ),
            dbc.ListGroup(tip_items, flush=True),
        ])
    ], )


def _whatif_agent_card(whatif_plan: dict):
    scenarios = whatif_plan.get("scenarios", [])
    budget = whatif_plan.get("budget", 0)

    if not scenarios:
        return dbc.Card([
            dbc.CardHeader("Interactive Investor Agent — ask follow-up questions or generate a brief on demand"),
            dbc.CardBody([
                html.P(
                    "Based on your latest prediction, run quick follow-up analysis or budget-constrained what-if planning:",
                    className="text-muted mb-3",
                ),
                dbc.Row([
                    dbc.Col([
                        dcc.Textarea(
                            id="inv-agent-question",
                            value="",
                            placeholder="Example: What are the top 3 improvements to increase ROI with limited budget?",
                            style={
                                "width": "100%",
                                "height": "150px",
                                "fontSize": "16px",
                                "padding": "12px",
                                "borderRadius": "10px",
                                "border": "1px solid #D1D1D6",
                            },
                        ),
                    ], md=8),
                dbc.Col([
                    dbc.Button("Ask Agent", id="inv-agent-ask-btn", color="primary", className="w-100 mb-2", n_clicks=0),
                    dbc.Button("Generate Investment Brief", id="inv-agent-brief-btn", color="secondary", outline=True, className="w-100 mb-3", n_clicks=0),
                    html.Hr(className="my-2"),
                    dbc.Label("What-if budget ($)"),
                    dbc.Input(
                        id="inv-whatif-budget",
                        type="number",
                        value=1500,
                        min=0,
                        max=50000,
                        className="mb-2",
                    ),
                    dbc.Button("Run What-if Optimizer", id="inv-whatif-generate-btn", color="dark", outline=True, className="w-100", n_clicks=0),
                ], md=4),
            ], className="mb-2"),
                dcc.Markdown(
                    "Run a prediction, then ask a question or generate a brief.",
                    id="inv-agent-response",
                    style={"fontSize": "14px"},
                    className="mb-0",
                ),
            ]),
        ], className="mt-3")

    rows = []
    for idx, s in enumerate(scenarios):
        uplift_color = "#198754" if s["uplift_usd"] >= 0 else "#dc3545"
        win_color = "#198754" if s["win_rate_delta"] >= 0 else "#dc3545"
        rows.append(
            dbc.Card([
                dbc.CardBody([
                    html.Div([
                        html.Span(f"Option {idx + 1}", className="fw-semibold"),
                        dbc.Badge(f"${s['estimated_budget']:,.0f}", color="light", text_color="dark", className="ms-2"),
                    ], className="mb-2"),
                    html.P(s["name"], className="mb-2", style={"fontWeight": "600", "fontSize": "14px"}),
                    html.Div([
                        html.Span(f"Predicted: ${s['predicted_price']:,.0f}", className="me-3"),
                        html.Span(f"Uplift: {s['uplift_usd']:+,.0f} ({s['uplift_pct']:+.1f}%)",
                                  style={"color": uplift_color, "fontWeight": "600"}, className="me-3"),
                        html.Span(f"Win-rate proxy: {s['win_rate_delta']:+.1f}",
                                  style={"color": win_color, "fontWeight": "600"}),
                    ], className="small mb-2"),
                    html.Ul([html.Li(change) for change in s.get("changes", [])], className="small mb-0"),
                ]),
            ], className="mb-2")
        )

    return dbc.Card([
        dbc.CardHeader("Interactive Investor Agent — ask follow-up questions or generate a brief on demand"),
        dbc.CardBody([
            html.P(
                "Based on your latest prediction, run quick follow-up analysis or budget-constrained what-if planning:",
                className="text-muted mb-3",
            ),
            dbc.Row([
                dbc.Col([
                    dcc.Textarea(
                        id="inv-agent-question",
                        value="",
                        placeholder="Example: What are the top 3 improvements to increase ROI with limited budget?",
                        style={
                            "width": "100%",
                            "height": "150px",
                            "fontSize": "16px",
                            "padding": "12px",
                            "borderRadius": "10px",
                            "border": "1px solid #D1D1D6",
                        },
                    ),
                ], md=8),
                dbc.Col([
                    dbc.Button("Ask Agent", id="inv-agent-ask-btn", color="primary", className="w-100 mb-2", n_clicks=0),
                    dbc.Button("Generate Investment Brief", id="inv-agent-brief-btn", color="secondary", outline=True, className="w-100 mb-3", n_clicks=0),
                    html.Hr(className="my-2"),
                    dbc.Label("What-if budget ($)"),
                    dbc.Input(
                        id="inv-whatif-budget",
                        type="number",
                        value=budget if budget else 1500,
                        min=0,
                        max=50000,
                        className="mb-2",
                    ),
                    dbc.Button("Run What-if Optimizer", id="inv-whatif-generate-btn", color="dark", outline=True, className="w-100", n_clicks=0),
                ], md=4),
            ], className="mb-2"),
            dcc.Markdown(
                "Optimizer complete. Review the top options below.",
                id="inv-agent-response",
                style={"fontSize": "14px"},
                className="mb-3",
            ),
            *rows,
        ]),
    ], className="mt-3")
